<?php wp_footer(); ?>

 <footer>
      <div class="container">
        <div class="d-flex justify-content-center align-items-center">
          <img src="img/logo-footer.svg" class="logo" ="" />
        </div>
        <div class="text-center text-white opacity-50 mt-24">
          A product of Creotopi
        </div>

        <div class="text-center text-white mt-48">Quick Links</div>
        <div
          class="d-flex flex-column flex-lg-row g-3 justify-content-center mt-24 text-white opacity-50 text-center"
        >
          <a href="#">Browse Components</a>
          <img src="img/line.svg" class="d-none d-lg-block" alt="" />
          <a href="#">Categoriess</a>
          <img src="img/line.svg" class="d-none d-lg-block" alt="" />
          <a href="#">New Releases</a>
          <img src="img/line.svg" class="d-none d-lg-block" alt="" />
          <a href="#">How it Works</a>
          <img src="img/line.svg" class="d-none d-lg-block" alt="" />
          <a href="#">License</a>
        </div>

        <div class="d-flex g-3 mt-48 social justify-content-center">
          <a href="#">
            <i class="ti ti-brand-instagram"></i>
          </a>
          <a href="#">
            <i class="ti ti-brand-figma"></i>
          </a>
        </div>

        <div class="text-center text-white opacity-50 mt-48">
          © 2026 ugokiui. All rights reserved.
        </div>
      </div>
    </footer>
    <script src="<?php echo get_template_directory_uri(); ?>/js/main.js"></script>
</body>
</html>
