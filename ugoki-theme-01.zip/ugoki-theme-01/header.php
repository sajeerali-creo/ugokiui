<!DOCTYPE html>
<html>
<head>
  <title><?php bloginfo('name'); ?></title>
  <?php wp_head(); ?>
 <link rel="stylesheet" href="style.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Comfortaa:wght@300..700&display=swap"
      rel="stylesheet"
    />
    <link
      rel="stylesheet"
      href="https://cdn.jsdelivr.net/npm/@tabler/icons-webfont@latest/dist/tabler-icons.min.css"
    />
</head>
<body>
      <!-- bg -->
    <canvas id="dotGrid"></canvas>
    <!-- end -->

    <header>
      <a href="/">
        <img src="img/logo.svg" class="logo" alt="" />
      </a>
      <div class="d-none d-lg-block">
        <div class="menu">
          <a href="/about.html">About UgokiUi</a>
          <a href="/component-library.html">Component Library</a>
          <a href="/how-to-use.html">How to use</a>
        </div>
      </div>
      <div class="d-none d-lg-block">
        <div class="cta-header">
          <a href="#" class="bt-s-auto g-1">
            Donate
            <img src="img/thumb.svg" alt="" />
          </a>
          <a href="#" class="bt-icon">
            <img src="img/discod.svg" alt="" />
          </a>
          <a href="#" class="bt-icon">
            <img src="img/github.svg" alt="" />
          </a>
          <a href="#" class="bt-icon">
            <img src="img/figma.svg" alt="" />
          </a>
        </div>
      </div>
      <div class="d-lg-none">
        <a href="#" class="bt-icon" onclick="openMenu()">
          <i class="ti ti-menu-3"></i>
        </a>
      </div>
    </header>

    <!-- offcanvas -->
    <div class="offcanvas-backdrop" id="backdrop" onclick="closeMenu()"></div>
    <!-- Offcanvas -->
    <div class="offcanvas" id="offcanvas">
      <div class="offcanvas-header">
        <button class="close-btn" onclick="closeMenu()">✕</button>
      </div>

      <nav class="offcanvas-menu">
        <a href="#">About UgokiUi</a>
        <a href="#">Component Library</a>
        <a href="#">How to use</a>
        <div class="small">
          <a href="#">FAQ</a>
          <a href="#">New Releases</a>
          <a href="#">Donate</a>
          <a href="#">Terms and Conditions</a>
        </div>

        <div class="cta-header d-flex g-2">
          <a href="#" class="bt-icon">
            <img src="img/discod.svg" alt="" />
          </a>
          <a href="#" class="bt-icon">
            <img src="img/github.svg" alt="" />
          </a>
          <a href="#" class="bt-icon">
            <img src="img/figma.svg" alt="" />
          </a>
        </div>
      </nav>
    </div>

